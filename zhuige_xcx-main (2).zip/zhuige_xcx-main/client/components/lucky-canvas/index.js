module.exports = require('./dist/index.umd.js')
